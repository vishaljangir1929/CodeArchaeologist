# CodeArchaeologist Report: Legacy Shop

## Summary

- Modules: 6
- Classes: 5
- Functions/methods: 13
- Lines of code: 135
- Call graph edges: 12
- Average complexity: 2.0
- Likely dead functions: 4
- Likely dead classes: 1
- Syntax errors: 0

## Modules

| Module | Classes | Functions | Imports | LOC |
| --- | ---: | ---: | ---: | ---: |
| `legacy_shop` | 0 | 0 | 0 | 2 |
| `legacy_shop.cli` | 0 | 2 | 4 | 21 |
| `legacy_shop.discounts` | 0 | 3 | 2 | 25 |
| `legacy_shop.models` | 3 | 3 | 2 | 38 |
| `legacy_shop.notifications` | 0 | 2 | 2 | 18 |
| `legacy_shop.service` | 2 | 3 | 7 | 31 |

## Complexity Hotspots

- No high-complexity functions found.

## Likely Dead Code

- Function `legacy_shop.discounts.unused_promo_code_normalizer` at legacy_shop/discounts.py:23
- Function `legacy_shop.models.CartItem.subtotal` at legacy_shop/models.py:18
- Function `legacy_shop.models.normalize_sku` at legacy_shop/models.py:36
- Function `legacy_shop.service.DebugCheckoutPrinter.print_order` at legacy_shop/service.py:29
- Class `legacy_shop.service.DebugCheckoutPrinter` at legacy_shop/service.py:28

## Generated Diagrams

- `architecture.svg`
- `call_graph.svg`
