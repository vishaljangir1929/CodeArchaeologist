# Module `legacy_shop.service`

- File: `legacy_shop/service.py`
- Lines of code: 31
- Imports: 7
- Classes: 2
- Functions/methods: 3

## Purpose Summary

Defines class-level behavior through CheckoutService, DebugCheckoutPrinter. Exposes callable logic such as CheckoutService.checkout, CheckoutService.validate_cart, DebugCheckoutPrinter.print_order. Uses imported dependencies that are included in the dependency graph.

## Imports

- `from __future__ import annotations`
- `from .discounts import loyalty_discount`
- `from .discounts import seasonal_discount`
- `from .models import CartItem`
- `from .models import Order`
- `from .models import calculate_total`
- `from .notifications import send_receipt`

## Classes

### `CheckoutService`
- Lines: 8-25
- Methods: 2

### `DebugCheckoutPrinter`
- Lines: 28-30
- Methods: 1


## Functions And Methods

### `CheckoutService.checkout(self, email, items, previous_orders)`
- Kind: method
- Lines: 9-16
- Complexity: 1
- Calls: `Order`, `calculate_total`, `loyalty_discount`, `round`, `seasonal_discount`, `self.validate_cart`, `send_receipt`

### `CheckoutService.validate_cart(self, items)`
- Kind: method
- Lines: 18-25
- Complexity: 5
- Calls: `ValueError`

### `DebugCheckoutPrinter.print_order(self, order)`
- Kind: method
- Lines: 29-30
- Complexity: 1
- Calls: `print`
