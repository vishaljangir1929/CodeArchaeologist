# Module `legacy_shop.discounts`

- File: `legacy_shop/discounts.py`
- Lines of code: 25
- Imports: 2
- Classes: 0
- Functions/methods: 3

## Purpose Summary

Exposes callable logic such as seasonal_discount, loyalty_discount, unused_promo_code_normalizer. Uses imported dependencies that are included in the dependency graph.

## Imports

- `from __future__ import annotations`
- `from datetime import date`

## Classes

- No classes.

## Functions And Methods

### `seasonal_discount(total, today)`
- Kind: function
- Lines: 6-12
- Complexity: 6
- Calls: `date.today`

### `loyalty_discount(total, previous_orders)`
- Kind: function
- Lines: 15-20
- Complexity: 3
- Calls: none detected

### `unused_promo_code_normalizer(code)`
- Kind: function
- Lines: 23-24
- Complexity: 1
- Calls: `code.strip`, `code.strip.replace`, `code.strip.replace.upper`
