# Module `legacy_shop.models`

- File: `legacy_shop/models.py`
- Lines of code: 38
- Imports: 2
- Classes: 3
- Functions/methods: 3

## Purpose Summary

Defines class-level behavior through Product, CartItem, Order. Exposes callable logic such as CartItem.subtotal, calculate_total, normalize_sku. Uses imported dependencies that are included in the dependency graph.

## Imports

- `from __future__ import annotations`
- `from dataclasses import dataclass`

## Classes

### `Product`
- Lines: 7-10
- Methods: 0

### `CartItem`
- Lines: 14-19
- Methods: 1

### `Order`
- Lines: 23-26
- Methods: 0


## Functions And Methods

### `CartItem.subtotal(self)`
- Kind: method
- Lines: 18-19
- Complexity: 1
- Calls: none detected

### `calculate_total(items)`
- Kind: function
- Lines: 29-33
- Complexity: 2
- Calls: `item.subtotal`, `round`

### `normalize_sku(raw_sku)`
- Kind: function
- Lines: 36-37
- Complexity: 1
- Calls: `raw_sku.strip`, `raw_sku.strip.upper`, `raw_sku.strip.upper.replace`
