# Module `legacy_shop.cli`

- File: `legacy_shop/cli.py`
- Lines of code: 21
- Imports: 4
- Classes: 0
- Functions/methods: 2

## Purpose Summary

Exposes callable logic such as build_demo_cart, main. Uses imported dependencies that are included in the dependency graph.

## Imports

- `from __future__ import annotations`
- `from .models import CartItem`
- `from .models import Product`
- `from .service import CheckoutService`

## Classes

- No classes.

## Functions And Methods

### `build_demo_cart()`
- Kind: function
- Lines: 7-10
- Complexity: 1
- Calls: `CartItem`, `Product`

### `main()`
- Kind: function
- Lines: 13-16
- Complexity: 1
- Calls: `CheckoutService`, `build_demo_cart`, `print`, `service.checkout`
