# Module `legacy_shop.notifications`

- File: `legacy_shop/notifications.py`
- Lines of code: 18
- Imports: 2
- Classes: 0
- Functions/methods: 2

## Purpose Summary

Exposes callable logic such as format_receipt, send_receipt. Uses imported dependencies that are included in the dependency graph.

## Imports

- `from __future__ import annotations`
- `from .models import Order`

## Classes

- No classes.

## Functions And Methods

### `format_receipt(order)`
- Kind: function
- Lines: 6-12
- Complexity: 2
- Calls: `item.subtotal`, `lines.append`

### `send_receipt(order)`
- Kind: function
- Lines: 15-17
- Complexity: 1
- Calls: `format_receipt`, `hash`
